// Утилиты для работы с часовыми поясами
export const getUserTimezone = (): string => {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone
  } catch {
    return "UTC"
  }
}

export const formatDateInTimezone = (
  date: string,
  time = "14:00:00",
  timezone: string,
  language: "en" | "ru" = "en",
): {
  localDate: string
  localTime: string
  fullDateTime: string
} => {
  try {
    const dateTime = new Date(`${date}T${time}`)

    const options: Intl.DateTimeFormatOptions = {
      timeZone: timezone,
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "long",
    }

    const timeOptions: Intl.DateTimeFormatOptions = {
      timeZone: timezone,
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }

    const fullOptions: Intl.DateTimeFormatOptions = {
      timeZone: timezone,
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }

    return {
      localDate: dateTime.toLocaleDateString(language === "ru" ? "ru-RU" : "en-US", options),
      localTime: dateTime.toLocaleTimeString(language === "ru" ? "ru-RU" : "en-US", timeOptions),
      fullDateTime: dateTime.toLocaleDateString(language === "ru" ? "ru-RU" : "en-US", fullOptions),
    }
  } catch {
    return {
      localDate: date,
      localTime: time,
      fullDateTime: `${date} ${time}`,
    }
  }
}

export const getTimezoneOffset = (timezone: string): string => {
  try {
    const now = new Date()
    const utc = new Date(now.getTime() + now.getTimezoneOffset() * 60000)
    const targetTime = new Date(utc.toLocaleString("en-US", { timeZone: timezone }))
    const diff = (targetTime.getTime() - utc.getTime()) / (1000 * 60 * 60)

    const sign = diff >= 0 ? "+" : "-"
    const hours = Math.floor(Math.abs(diff))
    const minutes = Math.round((Math.abs(diff) - hours) * 60)

    return `UTC${sign}${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
  } catch {
    return "UTC+00:00"
  }
}
