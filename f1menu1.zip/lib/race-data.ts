export const RACE_DATA_2025 = [
  {
    round: 1,
    name: { ru: "Гран-при Австралии", en: "Australian Grand Prix" },
    date: "2025-03-16",
    time: "14:00:00",
    circuit: {
      circuitId: "albert_park",
      circuitName: "Albert Park Circuit",
      location: {
        locality: "Melbourne",
        country: "Australia",
        lat: "-37.8497",
        long: "144.968",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Albert+Park+Circuit",
  },
  {
    round: 2,
    name: { ru: "Гран-при Китая", en: "Chinese Grand Prix" },
    date: "2025-03-23",
    time: "14:00:00",
    circuit: {
      circuitId: "shanghai",
      circuitName: "Shanghai International Circuit",
      location: {
        locality: "Shanghai",
        country: "China",
        lat: "31.3389",
        long: "121.2197",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Shanghai+Circuit",
  },
  {
    round: 3,
    name: { ru: "Гран-при Японии", en: "Japanese Grand Prix" },
    date: "2025-04-06",
    time: "14:00:00",
    circuit: {
      circuitId: "suzuka",
      circuitName: "Suzuka Circuit",
      location: {
        locality: "Suzuka",
        country: "Japan",
        lat: "34.8431",
        long: "136.5407",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Suzuka+Circuit",
  },
  {
    round: 4,
    name: { ru: "Гран-при Бахрейна", en: "Bahrain Grand Prix" },
    date: "2025-04-13",
    time: "18:00:00",
    circuit: {
      circuitId: "bahrain",
      circuitName: "Bahrain International Circuit",
      location: {
        locality: "Sakhir",
        country: "Bahrain",
        lat: "26.0325",
        long: "50.5106",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Bahrain+Circuit",
  },
  {
    round: 5,
    name: { ru: "Гран-при Саудовской Аравии", en: "Saudi Arabian Grand Prix" },
    date: "2025-04-20",
    time: "20:00:00",
    circuit: {
      circuitId: "jeddah",
      circuitName: "Jeddah Corniche Circuit",
      location: {
        locality: "Jeddah",
        country: "Saudi Arabia",
        lat: "21.6319",
        long: "39.1044",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Jeddah+Circuit",
  },
  {
    round: 6,
    name: { ru: "Гран-при Майами", en: "Miami Grand Prix" },
    date: "2025-05-04",
    time: "20:00:00",
    circuit: {
      circuitId: "miami",
      circuitName: "Miami International Autodrome",
      location: {
        locality: "Miami",
        country: "USA",
        lat: "25.9581",
        long: "-80.2389",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Miami+Circuit",
  },
  {
    round: 7,
    name: { ru: "Гран-при Эмилии-Романьи", en: "Emilia Romagna Grand Prix" },
    date: "2025-05-18",
    time: "15:00:00",
    circuit: {
      circuitId: "imola",
      circuitName: "Autodromo Enzo e Dino Ferrari",
      location: {
        locality: "Imola",
        country: "Italy",
        lat: "44.3439",
        long: "11.7167",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Imola+Circuit",
  },
  {
    round: 8,
    name: { ru: "Гран-pri Монако", en: "Monaco Grand Prix" },
    date: "2025-05-25",
    time: "15:00:00",
    circuit: {
      circuitId: "monaco",
      circuitName: "Circuit de Monaco",
      location: {
        locality: "Monte Carlo",
        country: "Monaco",
        lat: "43.7347",
        long: "7.4206",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Monaco+Circuit",
  },
  {
    round: 9,
    name: { ru: "Гран-при Испании", en: "Spanish Grand Prix" },
    date: "2025-06-01",
    time: "15:00:00",
    circuit: {
      circuitId: "catalunya",
      circuitName: "Circuit de Barcelona-Catalunya",
      location: {
        locality: "Barcelona",
        country: "Spain",
        lat: "41.57",
        long: "2.2611",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Barcelona+Circuit",
  },
  {
    round: 10,
    name: { ru: "Гран-при Канады", en: "Canadian Grand Prix" },
    date: "2025-06-15",
    time: "20:00:00",
    circuit: {
      circuitId: "villeneuve",
      circuitName: "Circuit Gilles Villeneuve",
      location: {
        locality: "Montreal",
        country: "Canada",
        lat: "45.5",
        long: "-73.5228",
      },
    },
    imageUrl: "/placeholder.svg?height=400&width=600&text=Montreal+Circuit",
  },
]

// Функция для получения актуальных данных о гонках
export function getCurrentSeasonRaces() {
  return RACE_DATA_2025.map((race) => ({
    season: "2025",
    round: race.round.toString(),
    raceName: race.name.en,
    date: race.date,
    time: race.time,
    circuit: race.circuit,
    imageUrl: race.imageUrl,
  }))
}

// Функция для определения последней завершенной гонки
export function getLastCompletedRace() {
  const now = new Date()
  const completedRaces = RACE_DATA_2025.filter((race) => new Date(race.date) < now)
  return completedRaces.length > 0 ? completedRaces[completedRaces.length - 1] : null
}
