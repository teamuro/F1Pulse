import type { Race, DriverStanding, ConstructorStanding, WeatherData, NewsItem } from "../types/f1"

// --- helpers --------------------------------------------------------------

function normalizeRace(raw: any): Race {
  // Circuit и Location приходят с заглавных букв
  const circuitRaw = raw.Circuit ?? raw.circuit ?? {}
  const locationRaw = circuitRaw.Location ?? circuitRaw.location ?? {}

  // Нормализуем результаты - приводим Driver/Constructor к driver/constructor
  const normalizeResults = (results: any[]) => {
    if (!results) return results
    return results.map((result: any) => ({
      ...result,
      driver: result.Driver ?? result.driver,
      constructor: result.Constructor ?? result.constructor,
    }))
  }

  return {
    season: raw.season ?? "",
    round: raw.round ?? "",
    raceName: raw.raceName ?? raw.RaceName ?? "",
    date: raw.date,
    time: raw.time,
    // приводим названия к camelCase
    circuit: {
      circuitId: circuitRaw.circuitId ?? "",
      circuitName: circuitRaw.circuitName ?? "",
      location: {
        lat: locationRaw.lat ?? "",
        long: locationRaw.long ?? "",
        locality: locationRaw.locality ?? "",
        country: locationRaw.country ?? "",
      },
    },
    // нормализуем результаты
    results: normalizeResults(raw.Results ?? raw.results),
    qualifying: normalizeResults(raw.QualifyingResults ?? raw.qualifying),
    sprint: normalizeResults(raw.SprintResults ?? raw.sprint),
    firstPractice: raw.FirstPractice ?? raw.firstPractice,
    secondPractice: raw.SecondPractice ?? raw.secondPractice,
    thirdPractice: raw.ThirdPractice ?? raw.thirdPractice,
  } as Race
}

function normalizeDriverStanding(raw: any) {
  return {
    position: raw.position,
    points: raw.points,
    wins: raw.wins,
    driver: raw.Driver ?? raw.driver,
    constructors: raw.Constructors ?? raw.constructors,
  } as DriverStanding
}

function normalizeConstructorStanding(raw: any) {
  return {
    position: raw.position,
    points: raw.points,
    wins: raw.wins,
    constructor: raw.Constructor ?? raw.constructor,
  } as ConstructorStanding
}

const ERGAST_BASE_URL = "https://api.jolpi.ca/ergast/f1"
const WEATHER_API_URL = "https://api.open-meteo.com/v1/forecast"

// Маппинг имен пилотов к их ID в Ergast API
const DRIVER_ID_MAP: { [key: string]: string } = {
  "Max Verstappen": "max_verstappen",
  "Lando Norris": "norris",
  "Charles Leclerc": "leclerc",
  "Oscar Piastri": "piastri",
  "Lewis Hamilton": "hamilton",
  "George Russell": "russell",
  "Fernando Alonso": "alonso",
  "Lance Stroll": "stroll",
  "Pierre Gasly": "gasly",
  "Franco Colapinto": "colapinto",
  "Esteban Ocon": "ocon",
  "Oliver Bearman": "bearman",
  "Gabriel Bortoleto": "bortoleto",
  "Nico Hülkenberg": "hulkenberg",
  "Liam Lawson": "lawson",
  "Isack Hadjar": "hadjar",
  "Alex Albon": "albon",
  "Carlos Sainz Jr.": "sainz",
  "Andrea Kimi Antonelli": "antonelli",
  "Yuki Tsunoda": "tsunoda",
  // Добавляем исторических пилотов для более точного поиска
  "Sebastian Vettel": "vettel",
  "Kimi Räikkönen": "raikkonen",
  "Daniel Ricciardo": "ricciardo",
  "Valtteri Bottas": "bottas",
  "Sergio Pérez": "perez",
}

export async function fetchCurrentSeason(): Promise<Race[]> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/current.json`)
    const data = await response.json()
    return (data.MRData.RaceTable.Races || []).map(normalizeRace)
  } catch (error) {
    console.error("Error fetching current season:", error)
    return []
  }
}

export async function fetchSeasonRaces(year: string): Promise<Race[]> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/${year}.json`)
    const data = await response.json()
    return (data.MRData.RaceTable.Races || []).map(normalizeRace)
  } catch (error) {
    console.error(`Error fetching ${year} season:`, error)
    return []
  }
}

export async function fetchRaceResults(year: string, round: string): Promise<Race | null> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/${year}/${round}/results.json`)
    const data = await response.json()
    const races = data.MRData.RaceTable.Races
    return races.length > 0 ? normalizeRace(races[0]) : null
  } catch (error) {
    console.error("Error fetching race results:", error)
    return null
  }
}

export async function fetchQualifyingResults(year: string, round: string): Promise<Race | null> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/${year}/${round}/qualifying.json`)
    const data = await response.json()
    const races = data.MRData.RaceTable.Races
    return races.length > 0 ? normalizeRace(races[0]) : null
  } catch (error) {
    console.error("Error fetching qualifying results:", error)
    return null
  }
}

export async function fetchSprintResults(year: string, round: string): Promise<Race | null> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/${year}/${round}/sprint.json`)
    const data = await response.json()
    const races = data.MRData.RaceTable.Races
    return races.length > 0 ? normalizeRace(races[0]) : null
  } catch (error) {
    console.error("Error fetching sprint results:", error)
    return null
  }
}

export async function fetchDriverStandings(year: string): Promise<DriverStanding[]> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/${year}/driverStandings.json`)
    const data = await response.json()
    const standings = data.MRData.StandingsTable.StandingsLists
    return standings.length > 0 ? standings[0].DriverStandings.map(normalizeDriverStanding) : []
  } catch (error) {
    console.error("Error fetching driver standings:", error)
    return []
  }
}

export async function fetchConstructorStandings(year: string): Promise<ConstructorStanding[]> {
  try {
    const response = await fetch(`${ERGAST_BASE_URL}/${year}/constructorStandings.json`)
    const data = await response.json()
    const standings = data.MRData.StandingsTable.StandingsLists
    return standings.length > 0 ? standings[0].ConstructorStandings.map(normalizeConstructorStanding) : []
  } catch (error) {
    console.error("Error fetching constructor standings:", error)
    return []
  }
}

// Новая функция для правильного поиска последней завершенной гонки
export async function fetchLastCompletedRace(): Promise<Race | null> {
  try {
    const currentYear = new Date().getFullYear()
    const baseUrl = `${ERGAST_BASE_URL}/${currentYear}/results`
    let offset = 0
    const completed: any[] = []
    const limit = 30

    while (true) {
      const response = await fetch(`${baseUrl}?limit=${limit}&offset=${offset}`)
      const data = await response.json()
      const races = data.MRData?.RaceTable?.Races ?? []

      if (races.length === 0) break

      // Фильтруем только реально завершенные гонки с результатами
      const now = new Date()
      const done = races.filter(
        (r: any) => r.Results && Array.isArray(r.Results) && r.Results.length > 0 && new Date(r.date) < now,
      )

      completed.push(...done)

      if (races.length < limit) break
      offset += limit
    }

    return completed.length ? normalizeRace(completed.at(-1)) : null
  } catch (error) {
    console.error("Error fetching last completed race:", error)
    return null
  }
}

export async function fetchLastRaceResults(): Promise<{
  race: Race | null
  qualifying: Race | null
  sprint: Race | null
}> {
  try {
    // Используем новую функцию для поиска последней завершенной гонки
    const lastRace = await fetchLastCompletedRace()

    if (!lastRace) {
      return { race: null, qualifying: null, sprint: null }
    }

    // Загружаем квалификацию и спринт для последней гонки
    const [qualiResp, sprintResp] = await Promise.all([
      fetch(`${ERGAST_BASE_URL}/${lastRace.season}/${lastRace.round}/qualifying.json`),
      fetch(`${ERGAST_BASE_URL}/${lastRace.season}/${lastRace.round}/sprint.json`),
    ])

    const [qualiData, sprintData] = await Promise.all([qualiResp.json(), sprintResp.json()])

    const qualifying =
      qualiData.MRData.RaceTable.Races.length > 0 ? normalizeRace(qualiData.MRData.RaceTable.Races[0]) : null
    const sprint =
      sprintData.MRData.RaceTable.Races.length > 0 ? normalizeRace(sprintData.MRData.RaceTable.Races[0]) : null

    return { race: lastRace, qualifying, sprint }
  } catch (error) {
    console.error("Error fetching last race results:", error)
    return { race: null, qualifying: null, sprint: null }
  }
}

export async function fetchWeatherData(lat: number, lon: number): Promise<WeatherData | null> {
  try {
    const response = await fetch(`${WEATHER_API_URL}?latitude=${lat}&longitude=${lon}&current_weather=true`)
    return await response.json()
  } catch (error) {
    console.error("Error fetching weather data:", error)
    return null
  }
}

export async function fetchF1News(language: "ru" | "en" = "en"): Promise<NewsItem[]> {
  try {
    // RSS → JSON service
    const feedUrl = language === "ru" ? "https://www.f1news.ru/export/news.xml" : "https://f1i.com/news/feed"

    const resp = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feedUrl)}`)
    const data = await resp.json()

    if (data.status !== "ok") return []

    return data.items.slice(0, 5).map((item: any) => ({
      title: item.title,
      link: item.link,
      published: item.pubDate,
      summary: item.description?.replace(/<[^>]*>/g, "").slice(0, 200) + "...",
      image: item.thumbnail || item.enclosure?.link,
    }))
  } catch (error) {
    console.error("Error fetching F1 news:", error)
    return []
  }
}

export const getFlagEmoji = (countryCode: string): string => {
  if (!countryCode) return ""

  const codePoints = countryCode
    .toUpperCase()
    .split("")
    .map((char) => 127397 + char.charCodeAt(0))
  return String.fromCodePoint(...codePoints)
}

export const getTeamColor = (teamName: string): string => {
  switch (teamName) {
    case "Red Bull":
      return "#0600EF"
    case "McLaren":
      return "#FF8700"
    case "Ferrari":
      return "#DC0000"
    case "Mercedes":
      return "#00D2BE"
    case "Aston Martin":
      return "#2D826D"
    case "Alpine":
      return "#2293D1"
    case "Haas":
      return "#B6BABD"
    case "Racing Bulls":
      return "#469BFF"
    case "Williams":
      return "#37BEDD"
    case "Kick Sauber":
      return "#5C2D91"
    default:
      return "#FFFFFF"
  }
}

export async function fetchDriverStats(driverName: string): Promise<{
  wins: number
  podiums: number
  races: number
  driver: any
}> {
  try {
    console.log(`Fetching career stats for ${driverName}...`)

    // Получаем driver ID из маппинга
    const driverId = DRIVER_ID_MAP[driverName]

    if (!driverId) {
      console.warn(`Driver ID not found for ${driverName}, falling back to name search`)
      return await fetchDriverStatsByName(driverName)
    }

    let totalWins = 0
    let totalPodiums = 0
    let totalRaces = 0
    let driverInfo = null
    let offset = 0
    const limit = 100

    console.log(`Using driver ID: ${driverId}`)

    // Получаем все результаты пилота с пагинацией
    while (true) {
      try {
        const url = `${ERGAST_BASE_URL}/drivers/${driverId}/results.json?limit=${limit}&offset=${offset}`
        console.log(`Fetching: ${url}`)

        const response = await fetch(url)
        const data = await response.json()

        const races = data.MRData?.RaceTable?.Races || []

        if (races.length === 0) {
          console.log(`No more races found at offset ${offset}`)
          break
        }

        console.log(`Found ${races.length} races at offset ${offset}`)

        for (const race of races) {
          const results = race.Results || []
          for (const result of results) {
            totalRaces++
            const position = Number.parseInt(result.position)
            if (position === 1) totalWins++
            if (position <= 3) totalPodiums++

            // Сохраняем информацию о пилоте (берем из первого найденного результата)
            if (!driverInfo) {
              driverInfo = result.Driver
            }
          }
        }

        // Если получили меньше результатов чем лимит, значит это последняя страница
        if (races.length < limit) {
          console.log(`Last page reached with ${races.length} races`)
          break
        }

        offset += limit
      } catch (pageError) {
        console.warn(`Error fetching page at offset ${offset}:`, pageError)
        break
      }
    }

    console.log(`Final stats for ${driverName}: ${totalWins} wins, ${totalPodiums} podiums, ${totalRaces} races`)

    return {
      wins: totalWins,
      podiums: totalPodiums,
      races: totalRaces,
      driver: driverInfo || {
        givenName: driverName.split(" ")[0] || "",
        familyName: driverName.split(" ").slice(1).join(" ") || "",
        nationality: "Unknown",
        dateOfBirth: "1990-01-01",
        permanentNumber: "0",
      },
    }
  } catch (error) {
    console.error("Error fetching driver career stats:", error)
    return {
      wins: 0,
      podiums: 0,
      races: 0,
      driver: {
        givenName: driverName.split(" ")[0] || "",
        familyName: driverName.split(" ").slice(1).join(" ") || "",
        nationality: "Unknown",
        dateOfBirth: "1990-01-01",
        permanentNumber: "0",
      },
    }
  }
}

// Fallback функция для поиска по имени (если ID не найден)
async function fetchDriverStatsByName(driverName: string): Promise<{
  wins: number
  podiums: number
  races: number
  driver: any
}> {
  try {
    console.log(`Fallback: searching by name for ${driverName}`)

    // Получаем данные за последние несколько сезонов с пагинацией
    const seasons = Array.from({ length: 10 }, (_, i) => 2015 + i) // 2015–2024
    let totalWins = 0
    let totalPodiums = 0
    let totalRaces = 0
    let driverInfo = null

    for (const season of seasons) {
      let offset = 0
      const limit = 100

      while (true) {
        try {
          const response = await fetch(`${ERGAST_BASE_URL}/${season}/results.json?limit=${limit}&offset=${offset}`)
          const data = await response.json()
          const races = data.MRData?.RaceTable?.Races || []

          if (races.length === 0) break

          for (const race of races) {
            const results = race.Results || []
            const driverResult = results.find((result: any) => {
              const fullName = `${result.Driver.givenName} ${result.Driver.familyName}`
              return fullName === driverName
            })

            if (driverResult) {
              totalRaces++
              const position = Number.parseInt(driverResult.position)
              if (position === 1) totalWins++
              if (position <= 3) totalPodiums++

              if (!driverInfo) {
                driverInfo = driverResult.Driver
              }
            }
          }

          if (races.length < limit) break
          offset += limit
        } catch (pageError) {
          console.warn(`Error fetching ${season} page at offset ${offset}:`, pageError)
          break
        }
      }
    }

    return {
      wins: totalWins,
      podiums: totalPodiums,
      races: totalRaces,
      driver: driverInfo || {
        givenName: driverName.split(" ")[0] || "",
        familyName: driverName.split(" ").slice(1).join(" ") || "",
        nationality: "Unknown",
        dateOfBirth: "1990-01-01",
        permanentNumber: "0",
      },
    }
  } catch (error) {
    console.error("Error in fallback driver stats fetch:", error)
    return {
      wins: 0,
      podiums: 0,
      races: 0,
      driver: {
        givenName: driverName.split(" ")[0] || "",
        familyName: driverName.split(" ").slice(1).join(" ") || "",
        nationality: "Unknown",
        dateOfBirth: "1990-01-01",
        permanentNumber: "0",
      },
    }
  }
}
