import { type NextRequest, NextResponse } from "next/server"

const OPENROUTER_API_KEY =
  process.env.OPENROUTER_API_KEY || "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"

export async function POST(request: NextRequest) {
  try {
    const { question } = await request.json()

    if (!question) {
      return NextResponse.json({ error: "Question is required" }, { status: 400 })
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://f1pulse.vercel.app",
        "X-Title": "F1 AI Assistant",
      },
      body: JSON.stringify({
        model: "mistralai/mistral-7b-instruct:free",
        messages: [
          {
            role: "system",
            content:
              "Ты эксперт по Формуле 1. Отвечай понятно и кратко на русском или английском языке в зависимости от языка вопроса. Предоставляй точную информацию о гонках, пилотах, командах, технических аспектах и истории F1.",
          },
          {
            role: "user",
            content: question,
          },
        ],
        max_tokens: 500,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json({ error: errorData.error?.message || "AI service error" }, { status: response.status })
    }

    const data = await response.json()
    const answer = data.choices?.[0]?.message?.content || "Извините, не удалось получить ответ."

    return NextResponse.json({ answer })
  } catch (error) {
    console.error("AI API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
