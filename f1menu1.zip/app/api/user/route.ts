import { type NextRequest, NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"

const dataFilePath = path.resolve("./user_data.json")

async function readUserData() {
  try {
    const data = await fs.readFile(dataFilePath, "utf-8")
    return JSON.parse(data)
  } catch {
    return {}
  }
}

async function writeUserData(data: any) {
  await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2), "utf-8")
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { userId, favorite_driver, favorite_team, telegram_id } = body

  if (!userId) return NextResponse.json({ error: "Missing userId" }, { status: 400 })

  const data = await readUserData()

  data[userId] = {
    ...data[userId],
    favorite_driver,
    favorite_team,
    telegram_id,
  }

  await writeUserData(data)

  return NextResponse.json({ success: true, data: data[userId] })
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const userId = searchParams.get("userId")
  const data = await readUserData()
  return NextResponse.json({ success: true, data: data[userId] ?? {} })
}
