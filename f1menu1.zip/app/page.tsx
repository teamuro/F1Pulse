import F1PulseApp from "../components/f1-pulse-app"

export default function Page() {
  return <F1PulseApp />
}
