"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Menu, X, Trophy, Users, MapPin, BarChart3, Calendar, Clock, Flag, Zap } from "lucide-react"

const menuItems = [
  { icon: Calendar, label: "Race Schedule", href: "#schedule" },
  { icon: Clock, label: "Results", href: "#results" },
  { icon: BarChart3, label: "Standings", href: "#standings" },
  { icon: Users, label: "Drivers & Teams", href: "#paddock" },
  { icon: Zap, label: "News", href: "#news" },
  { icon: Trophy, label: "AI Assistant", href: "#ai" },
  { icon: MapPin, label: "Weather", href: "#weather" },
  { icon: Flag, label: "Settings", href: "#settings" },
]

export default function F1Menu() {
  const [isOpen, setIsOpen] = useState(false)
  const [activeItem, setActiveItem] = useState("Race Schedule")

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-red-900">
      {/* Header */}
      <header className="relative z-50 bg-black/80 backdrop-blur-md border-b border-red-500/20">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-lg flex items-center justify-center">
              <Flag className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">F1Pulse</h1>
              <p className="text-red-400 text-sm">Telegram Bot UI</p>
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(!isOpen)}
            className="text-white hover:bg-red-500/20 hover:text-red-400"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-40 bg-black/90 backdrop-blur-sm lg:hidden">
          <div className="pt-20 px-4">
            <Card className="bg-gray-900/90 border-red-500/20">
              <div className="p-6 space-y-4">
                {menuItems.map((item) => {
                  const Icon = item.icon
                  return (
                    <button
                      key={item.label}
                      onClick={() => {
                        setActiveItem(item.label)
                        setIsOpen(false)
                      }}
                      className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-red-500/20 transition-colors text-left"
                    >
                      <Icon className="w-5 h-5 text-red-400" />
                      <span className="text-white font-medium">{item.label}</span>
                    </button>
                  )
                })}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Desktop Navigation */}
      <nav className="hidden lg:block bg-black/60 backdrop-blur-md border-b border-red-500/10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center space-x-1">
            {menuItems.map((item) => {
              const Icon = item.icon
              const isActive = activeItem === item.label
              return (
                <button
                  key={item.label}
                  onClick={() => setActiveItem(item.label)}
                  className={`flex items-center space-x-2 px-6 py-4 transition-all duration-200 relative group ${
                    isActive ? "text-red-400 bg-red-500/10" : "text-gray-300 hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-medium">{item.label}</span>
                  {isActive && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-red-500 to-red-600" />
                  )}
                </button>
              )
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4">{activeItem}</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-red-500 to-red-600 mx-auto mb-6" />
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Stay ahead in the race with real-time updates, F1 statistics, and live results from your favorite drivers and teams — all inside Telegram.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card
              key={i}
              className="bg-gray-900/50 border-gray-700/50 hover:border-red-500/30 transition-all duration-300 group"
            >
              <div className="p-6">
                <div className="w-full h-32 bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg mb-4 flex items-center justify-center group-hover:from-red-900/20 group-hover:to-red-800/20 transition-all duration-300">
                  <div className="text-gray-500 group-hover:text-red-400 transition-colors">
                    <Flag className="w-8 h-8" />
                  </div>
                </div>
                <h3 className="text-white font-semibold mb-2">F1Pulse Card {i}</h3>
                <p className="text-gray-400 text-sm">
                  Access race data, driver info, and live insights — straight from the pit wall.
                </p>
              </div>
            </Card>
          ))}
        </div>

        {/* Racing Stripe Decoration */}
        <div className="mt-16 flex justify-center">
          <div className="flex space-x-2">
            {[...Array(20)].map((_, i) => (
              <div key={i} className={`w-8 h-2 ${i % 2 === 0 ? "bg-white" : "bg-red-500"} transform skew-x-12`} />
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
