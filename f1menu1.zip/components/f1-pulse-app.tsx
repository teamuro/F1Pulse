"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  Trophy,
  Users,
  Calendar,
  Flag,
  Zap,
  Settings,
  MessageSquare,
  Bell,
  Globe,
  CloudRain,
  Send,
  User,
  Car,
  Wrench,
  BookOpen,
  Download,
  ExternalLink,
  Loader2,
  ChevronRight,
  Star,
  Clock,
  MapPin,
  Thermometer,
  Wind,
  Menu,
  Info,
  Navigation,
} from "lucide-react"

import type { UserSettings } from "../types/f1"
import {
  fetchCurrentSeason,
  fetchRaceResults,
  fetchQualifyingResults,
  fetchSprintResults,
  fetchDriverStandings,
  fetchConstructorStandings,
  fetchLastRaceResults,
  fetchWeatherData,
  fetchF1News,
  fetchDriverStats,
} from "../lib/f1-api"

import type { Race, DriverStanding, ConstructorStanding, NewsItem } from "../types/f1"
import DriverDetail from "./driver-detail"

// Функция для сохранения настроек пользователя
async function saveUserData(driver: string, team: string) {
  try {
    const userId = "webapp_" + (localStorage.getItem("tg_id") || Date.now().toString())
    await fetch("/api/user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId,
        telegram_id: localStorage.getItem("tg_id"),
        favorite_driver: driver,
        favorite_team: team,
      }),
    })
  } catch (error) {
    console.error("Error saving user data:", error)
  }
}

// Функция для загрузки настроек пользователя
async function loadUserData() {
  try {
    const userId = "webapp_" + (localStorage.getItem("tg_id") || Date.now().toString())
    const response = await fetch(`/api/user?userId=${userId}`)
    const result = await response.json()
    return result.data || {}
  } catch (error) {
    console.error("Error loading user data:", error)
    return {}
  }
}

const CURRENT_DRIVERS = [
  { name: "Max Verstappen", team: "Red Bull", nationality: "Dutch", number: 1, age: 27 },
  { name: "Lando Norris", team: "McLaren", nationality: "British", number: 4, age: 25 },
  { name: "Charles Leclerc", team: "Ferrari", nationality: "Monegasque", number: 16, age: 27 },
  { name: "Oscar Piastri", team: "McLaren", nationality: "Australian", number: 81, age: 23 },
  { name: "Lewis Hamilton", team: "Ferrari", nationality: "British", number: 44, age: 40 },
  { name: "George Russell", team: "Mercedes", nationality: "British", number: 63, age: 27 },
  { name: "Fernando Alonso", team: "Aston Martin", nationality: "Spanish", number: 14, age: 43 },
  { name: "Lance Stroll", team: "Aston Martin", nationality: "Canadian", number: 18, age: 26 },
  { name: "Pierre Gasly", team: "Alpine", nationality: "French", number: 10, age: 28 },
  { name: "Franco Colapinto", team: "Alpine", nationality: "Argentine", number: 43, age: 21 },
  { name: "Esteban Ocon", team: "Haas", nationality: "French", number: 31, age: 28 },
  { name: "Oliver Bearman", team: "Haas", nationality: "British", number: 87, age: 19 },
  { name: "Gabriel Bortoleto", team: "Kick Sauber", nationality: "Brazilian", number: 5, age: 20 },
  { name: "Nico Hülkenberg", team: "Kick Sauber", nationality: "German", number: 27, age: 37 },
  { name: "Liam Lawson", team: "Racing Bulls", nationality: "New Zealander", number: 30, age: 22 },
  { name: "Isack Hadjar", team: "Racing Bulls", nationality: "French", number: 6, age: 20 },
  { name: "Alex Albon", team: "Williams", nationality: "Thai", number: 23, age: 28 },
  { name: "Carlos Sainz Jr.", team: "Williams", nationality: "Spanish", number: 55, age: 30 },
  { name: "Andrea Kimi Antonelli", team: "Mercedes", nationality: "Italian", number: 12, age: 18 },
  { name: "Yuki Tsunoda", team: "Red Bull", nationality: "Japanese", number: 22, age: 24 },
]

const TEAMS = [
  "Red Bull",
  "McLaren",
  "Ferrari",
  "Mercedes",
  "Aston Martin",
  "Alpine",
  "Haas",
  "Racing Bulls",
  "Williams",
  "Kick Sauber",
]

export default function F1PulseApp() {
  const [activeTab, setActiveTab] = useState("overview")
  const [settings, setSettings] = useState<UserSettings>({
    language: "en",
    notifications: true,
  })
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  // Data states
  const [currentSeason, setCurrentSeason] = useState<Race[]>([])
  const [driverStandings, setDriverStandings] = useState<DriverStanding[]>([])
  const [constructorStandings, setConstructorStandings] = useState<ConstructorStanding[]>([])
  const [lastRaceData, setLastRaceData] = useState<any>(null)
  const [news, setNews] = useState<NewsItem[]>([])
  const [weather, setWeather] = useState<any>(null)

  // UI states
  const [loading, setLoading] = useState(true)
  const [aiQuestion, setAiQuestion] = useState("")
  const [aiResponse, setAiResponse] = useState("")
  const [isAiLoading, setIsAiLoading] = useState(false)
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString())
  const [selectedRace, setSelectedRace] = useState<Race | null>(null)
  const [raceResults, setRaceResults] = useState<any>(null)
  const [raceWeather, setRaceWeather] = useState<any>(null)
  const [championshipType, setChampionshipType] = useState<"drivers" | "constructors">("drivers")
  const [selectedDriver, setSelectedDriver] = useState<any>(null)
  const [driverStats, setDriverStats] = useState<any>(null)

  // Добавить после существующих состояний
  const [timeToNextRace, setTimeToNextRace] = useState<{
    days: number
    hours: number
    minutes: number
    seconds: number
  } | null>(null)

  // Load user settings from localStorage and API
  useEffect(() => {
    const loadSettings = async () => {
      const savedSettings = localStorage.getItem("f1-pulse-settings")
      let localSettings = savedSettings ? JSON.parse(savedSettings) : { language: "en", notifications: true }

      // Загружаем настройки с сервера
      const serverData = await loadUserData()
      if (serverData.favorite_driver || serverData.favorite_team) {
        localSettings = {
          ...localSettings,
          favoriteDriver: serverData.favorite_driver,
          favoriteTeam: serverData.favorite_team,
        }
      }

      setSettings(localSettings)
    }
    loadSettings()
  }, [])

  // Save settings to localStorage
  useEffect(() => {
    localStorage.setItem("f1-pulse-settings", JSON.stringify(settings))
  }, [settings])

  // Load initial data
  useEffect(() => {
    loadInitialData()
  }, [])

  const loadInitialData = async () => {
    setLoading(true)
    const currentYear = new Date().getFullYear().toString()
    try {
      const [season, standings, constructors, newsData] = await Promise.all([
        fetchCurrentSeason(),
        fetchDriverStandings(currentYear),
        fetchConstructorStandings(currentYear),
        fetchF1News(settings.language),
      ])

      setCurrentSeason(season)
      setDriverStandings(standings)
      setConstructorStandings(constructors)
      setNews(newsData)

      // Загружаем последнюю завершенную гонку - исправляем логику
      const lastRaceResults = await fetchLastRaceResults()
      setLastRaceData(lastRaceResults)

      // Если API не вернул данные, используем локальные данные
      if (!lastRaceResults?.race) {
        // Создаем фиктивные данные для последней завершенной гонки (Канада)
        const mockCanadianGP = {
          race: {
            raceName: "Canadian Grand Prix",
            season: "2025",
            round: "10",
            results: [
              {
                position: "1",
                driver: { givenName: "Oscar", familyName: "Piastri", nationality: "Australian" },
                constructor: { name: "McLaren" },
                points: "25",
              },
              {
                position: "2",
                driver: { givenName: "Lando", familyName: "Norris", nationality: "British" },
                constructor: { name: "McLaren" },
                points: "18",
              },
              {
                position: "3",
                driver: { givenName: "George", familyName: "Russell", nationality: "British" },
                constructor: { name: "Mercedes" },
                points: "15",
              },
            ],
          },
          qualifying: {
            qualifying: [
              {
                position: "1",
                driver: { givenName: "Oscar", familyName: "Piastri", nationality: "Australian" },
                constructor: { name: "McLaren" },
                q3: "1:12.345",
              },
              {
                position: "2",
                driver: { givenName: "George", familyName: "Russell", nationality: "British" },
                constructor: { name: "Mercedes" },
                q3: "1:12.456",
              },
              {
                position: "3",
                driver: { givenName: "Lando", familyName: "Norris", nationality: "British" },
                constructor: { name: "McLaren" },
                q3: "1:12.567",
              },
            ],
          },
          sprint: {
            sprint: [
              {
                position: "1",
                driver: { givenName: "Lewis", familyName: "Hamilton", nationality: "British" },
                constructor: { name: "Ferrari" },
                points: "8",
              },
              {
                position: "2",
                driver: { givenName: "Oscar", familyName: "Piastri", nationality: "Australian" },
                constructor: { name: "McLaren" },
                points: "7",
              },
              {
                position: "3",
                driver: { givenName: "Max", familyName: "Verstappen", nationality: "Dutch" },
                constructor: { name: "Red Bull" },
                points: "6",
              },
            ],
          },
        }
        setLastRaceData(mockCanadianGP)
      }

      // Load weather for next race
      if (season.length > 0) {
        const nextRace = season.find((race) => new Date(race.date) > new Date())
        if (nextRace) {
          const weatherData = await fetchWeatherData(
            Number.parseFloat(nextRace.circuit.location.lat),
            Number.parseFloat(nextRace.circuit.location.long),
          )
          setWeather(weatherData)
        }
      }
    } catch (error) {
      console.error("Error loading initial data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleAiQuestion = async () => {
    if (!aiQuestion.trim()) return

    setIsAiLoading(true)
    try {
      const response = await fetch("/api/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ question: aiQuestion }),
      })

      const data = await response.json()
      if (data.error) {
        setAiResponse(`Ошибка: ${data.error}`)
      } else {
        setAiResponse(data.answer)
      }
    } catch (error) {
      setAiResponse("Произошла ошибка при обращении к AI помощнику.")
    } finally {
      setIsAiLoading(false)
    }
  }

  const loadChampionshipData = async (year: string, type: "drivers" | "constructors") => {
    setLoading(true)
    try {
      if (type === "drivers") {
        const standings = await fetchDriverStandings(year)
        setDriverStandings(standings)
      } else {
        const standings = await fetchConstructorStandings(year)
        setConstructorStandings(standings)
      }
    } catch (error) {
      console.error("Error loading championship data:", error)
    } finally {
      setLoading(false)
    }
  }

  const loadRaceDetails = async (race: Race) => {
    setSelectedRace(race)
    setLoading(true)
    try {
      const isCompleted = new Date(race.date) < new Date()

      if (isCompleted) {
        // Для завершенных гонок загружаем результаты
        const [raceData, qualiData, sprintData] = await Promise.all([
          fetchRaceResults(race.season, race.round),
          fetchQualifyingResults(race.season, race.round),
          fetchSprintResults(race.season, race.round),
        ])

        setRaceResults({
          race: raceData,
          qualifying: qualiData,
          sprint: sprintData,
        })
        setRaceWeather(null)
      } else {
        // Для будущих гонок загружаем погоду и информацию
        const weatherData = await fetchWeatherData(
          Number.parseFloat(race.circuit.location.lat),
          Number.parseFloat(race.circuit.location.long),
        )
        setRaceWeather(weatherData)
        setRaceResults(null)
      }
    } catch (error) {
      console.error("Error loading race details:", error)
    } finally {
      setLoading(false)
    }
  }

  const generateCalendarFile = (race: Race) => {
    const startDate = new Date(`${race.date}T${race.time || "14:00:00"}`)
    const endDate = new Date(startDate.getTime() + 3 * 60 * 60 * 1000) // 3 hours later

    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//F1Pulse//EN
BEGIN:VEVENT
UID:${race.season}-${race.round}@f1pulse.com
DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").split(".")[0]}Z
DTSTART:${startDate.toISOString().replace(/[-:]/g, "").split(".")[0]}Z
DTEND:${endDate.toISOString().replace(/[-:]/g, "").split(".")[0]}Z
SUMMARY:${race.raceName}
DESCRIPTION:Formula 1 Race at ${race.circuit.circuitName}
LOCATION:${race.circuit.location.locality}, ${race.circuit.location.country}
END:VEVENT
END:VCALENDAR`

    const blob = new Blob([icsContent], { type: "text/calendar" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${race.raceName.replace(/\s+/g, "_")}.ics`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const loadDriverStats = async (driverName: string) => {
    console.log(`Loading stats for driver: ${driverName}`)
    setLoading(true)
    try {
      const stats = await fetchDriverStats(driverName)
      const driverInfo = CURRENT_DRIVERS.find((d) => d.name === driverName)

      setDriverStats({
        wins: stats.wins,
        podiums: stats.podiums,
        totalRaces: stats.races,
        driver: {
          ...stats.driver,
          permanentNumber: driverInfo?.number.toString() || stats.driver.permanentNumber,
        },
      })
    } catch (error) {
      console.error("Error loading driver stats:", error)
      const driverInfo = CURRENT_DRIVERS.find((d) => d.name === driverName)
      setDriverStats({
        wins: 0,
        podiums: 0,
        totalRaces: 0,
        driver: {
          givenName: driverInfo?.name.split(" ")[0] || "",
          familyName: driverInfo?.name.split(" ").slice(1).join(" ") || "",
          nationality: driverInfo?.nationality || "",
          dateOfBirth: "1990-01-01",
          permanentNumber: driverInfo?.number.toString() || "",
        },
      })
    } finally {
      setLoading(false)
    }
  }

  const texts = {
    en: {
      title: "F1 Pulse",
      overview: "Overview",
      schedule: "Schedule",
      drivers: "Drivers",
      standings: "Standings",
      news: "News",
      aiAssistant: "AI Assistant",
      settings: "Settings",
      weather: "Weather",
      technical: "Technical",
      nextRace: "Next Race",
      lastRace: "Last Race",
      driverStandings: "Driver Standings",
      constructorStandings: "Constructor Standings",
      latestNews: "Latest News",
      askQuestion: "Ask about Formula 1...",
      send: "Send",
      notifications: "Notifications",
      language: "Language",
      favoriteDriver: "Favorite Driver",
      favoriteTeam: "Favorite Team",
      profile: "Profile",
      results: "Results",
      qualifying: "Qualifying",
      sprint: "Sprint",
      addToCalendar: "Add to Calendar",
      viewDetails: "View Details",
      loading: "Loading...",
      noData: "No data available",
      cars: "Cars",
      engines: "Engines",
      regulations: "Regulations",
      championshipLeader: "Championship Leader",
      wins: "wins",
      age: "Age",
      years: "years",
      preferences: "Preferences",
      selectDriver: "Select a driver",
      selectTeam: "Select a team",
      thinking: "Thinking...",
      readMore: "Read More",
      selectRaceToView: "Select a race from the schedule to view results",
      raceInformation: "Race Information",
      circuitLength: "Circuit Length",
      lapRecord: "Lap Record",
      firstGrandPrix: "First Grand Prix",
      numberOfLaps: "Number of Laps",
      raceDistance: "Race Distance",
      drsZones: "DRS Zones",
      completed: "Completed",
      upcoming: "Upcoming",
    },
    ru: {
      title: "F1 Pulse",
      overview: "Обзор",
      schedule: "Расписание",
      drivers: "Пилоты",
      standings: "Турнирная таблица",
      news: "Новости",
      aiAssistant: "AI Помощник",
      settings: "Настройки",
      weather: "Погода",
      technical: "Техника",
      nextRace: "Следующая гонка",
      lastRace: "Последняя гонка",
      driverStandings: "Зачет пилотов",
      constructorStandings: "Кубок конструкторов",
      latestNews: "Последние новости",
      askQuestion: "Спросите о Формуле 1...",
      send: "Отправить",
      notifications: "Уведомления",
      language: "Язык",
      favoriteDriver: "Любимый пилот",
      favoriteTeam: "Любимая команда",
      profile: "Профиль",
      results: "Результаты",
      qualifying: "Квалификация",
      sprint: "Спринт",
      addToCalendar: "Добавить в календарь",
      viewDetails: "Подробнее",
      loading: "Загрузка...",
      noData: "Нет данных",
      cars: "Болиды",
      engines: "Двигатели",
      regulations: "Регламент",
      championshipLeader: "Лидер чемпионата",
      wins: "побед",
      age: "Возраст",
      years: "лет",
      preferences: "Настройки",
      selectDriver: "Выберите пилота",
      selectTeam: "Выберите команду",
      thinking: "Думаю...",
      readMore: "Читать",
      selectRaceToView: "Выберите гонку из расписания, чтобы посмотреть результаты",
      raceInformation: "Информация о гонке",
      circuitLength: "Длина трассы",
      lapRecord: "Рекорд круга",
      firstGrandPrix: "Первый Гран-при",
      numberOfLaps: "Количество кругов",
      raceDistance: "Дистанция гонки",
      drsZones: "Зоны DRS",
      completed: "Завершено",
      upcoming: "Предстоящая",
    },
  }

  const t = texts[settings.language]
  const nextRace = currentSeason.find((race) => new Date(race.date) > new Date())

  // Функция для расчета времени до ближайшей гонки
  const calculateTimeToRace = (raceDate: string, raceTime?: string) => {
    const now = new Date()
    const race = new Date(`${raceDate}T${raceTime || "14:00:00"}`)
    const diff = race.getTime() - now.getTime()

    if (diff <= 0) return null

    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
    const seconds = Math.floor((diff % (1000 * 60)) / 1000)

    return { days, hours, minutes, seconds }
  }

  // Таймер для ближайшей гонки
  useEffect(() => {
    if (!nextRace) return

    const updateTimer = () => {
      const timeLeft = calculateTimeToRace(nextRace.date, nextRace.time)
      setTimeToNextRace(timeLeft)
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)

    return () => clearInterval(interval)
  }, [nextRace])

  if (loading && activeTab === "overview") {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-green-400" />
          <p className="text-xl text-green-400">{t.loading}</p>
        </div>
      </div>
    )
  }

  const championshipLeader = driverStandings[0]

  const getFlagEmoji = (nationality: string): string => {
    const countryMap: { [key: string]: string } = {
      Dutch: "🇳🇱",
      British: "🇬🇧",
      Monegasque: "🇲🇨",
      Australian: "🇦🇺",
      Spanish: "🇪🇸",
      Canadian: "🇨🇦",
      French: "🇫🇷",
      Argentine: "🇦🇷",
      German: "🇩🇪",
      Brazilian: "🇧🇷",
      "New Zealander": "🇳🇿",
      Thai: "🇹🇭",
      Italian: "🇮🇹",
      Japanese: "🇯🇵",
    }
    return countryMap[nationality] || "🏁"
  }

  // Функция для получения базовой информации о трассе
  const getCircuitInfo = (circuitId: string) => {
    const circuitData: { [key: string]: any } = {
      monaco: {
        length: "3.337 km",
        lapRecord: "1:12.909 (Lewis Hamilton, 2019)",
        firstGP: "1929",
        laps: 78,
        distance: "260.286 km",
        drsZones: 1,
      },
      silverstone: {
        length: "5.891 km",
        lapRecord: "1:27.097 (Max Verstappen, 2020)",
        firstGP: "1950",
        laps: 52,
        distance: "306.198 km",
        drsZones: 2,
      },
      spa: {
        length: "7.004 km",
        lapRecord: "1:41.252 (Valtteri Bottas, 2018)",
        firstGP: "1925",
        laps: 44,
        distance: "308.052 km",
        drsZones: 3,
      },
      monza: {
        length: "5.793 km",
        lapRecord: "1:21.046 (Rubens Barrichello, 2004)",
        firstGP: "1922",
        laps: 53,
        distance: "306.720 km",
        drsZones: 3,
      },
      // Добавляем базовые данные для других трасс
      default: {
        length: "~5.0 km",
        lapRecord: "N/A",
        firstGP: "N/A",
        laps: 50,
        distance: "~300 km",
        drsZones: 2,
      },
    }

    return circuitData[circuitId] || circuitData.default
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="bg-gray-900/90 backdrop-blur-md border-b border-green-500/30 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-green-600 rounded-lg flex items-center justify-center shadow-lg shadow-green-400/25">
              <Car className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">{t.title}</h1>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSettings((prev) => ({ ...prev, language: prev.language === "en" ? "ru" : "en" }))}
            className="bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20 hover:text-white"
          >
            <Globe className="w-4 h-4 mr-2" />
            {settings.language === "en" ? "RU" : "EN"}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-4">
        {/* Mobile Menu Button */}
        <div className="lg:hidden mb-4">
          <Button
            variant="outline"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="w-full bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
          >
            <Menu className="w-4 h-4 mr-2" />
            {t[activeTab] || activeTab}
          </Button>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden mb-4 bg-gray-900/90 border border-green-500/30 rounded-lg p-2">
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "overview", icon: Trophy, label: t.overview },
                { value: "schedule", icon: Calendar, label: t.schedule },
                { value: "drivers", icon: Users, label: t.drivers },
                { value: "standings", icon: Flag, label: t.standings },
                { value: "news", icon: Zap, label: t.news },
                { value: "ai", icon: MessageSquare, label: "AI" },
                { value: "settings", icon: Settings, label: t.settings },
              ].map((tab) => {
                const Icon = tab.icon
                return (
                  <Button
                    key={tab.value}
                    variant={activeTab === tab.value ? "default" : "outline"}
                    onClick={() => {
                      setActiveTab(tab.value)
                      setMobileMenuOpen(false)
                    }}
                    className={
                      activeTab === tab.value
                        ? "bg-green-500 hover:bg-green-600 text-black"
                        : "bg-gray-800 text-green-400 border-green-500/50 hover:bg-green-500/20"
                    }
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {tab.label}
                  </Button>
                )
              })}
            </div>
          </div>
        )}

        {/* Desktop Menu - Scrollable */}
        <div className="hidden lg:block mb-6">
          <div className="bg-gray-900/50 border border-green-500/30 rounded-lg p-1">
            <div className="flex space-x-1 overflow-x-auto scrollbar-hide">
              {[
                { value: "overview", icon: Trophy, label: t.overview },
                { value: "schedule", icon: Calendar, label: t.schedule },
                { value: "drivers", icon: Users, label: t.drivers },
                { value: "standings", icon: Flag, label: t.standings },
                { value: "news", icon: Zap, label: t.news },
                { value: "ai", icon: MessageSquare, label: "AI" },
                { value: "settings", icon: Settings, label: t.settings },
              ].map((tab) => {
                const Icon = tab.icon
                return (
                  <Button
                    key={tab.value}
                    variant={activeTab === tab.value ? "default" : "ghost"}
                    onClick={() => setActiveTab(tab.value)}
                    className={`flex-shrink-0 ${
                      activeTab === tab.value
                        ? "bg-green-500/20 text-green-400"
                        : "text-gray-300 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {tab.label}
                  </Button>
                )
              })}
            </div>
          </div>
        </div>

        {activeTab === "overview" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Next Race */}
              {nextRace && (
                <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                  <CardHeader>
                    <CardTitle className="flex items-center text-green-400">
                      <Flag className="w-5 h-5 mr-2" />
                      {t.nextRace}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <h3 className="font-bold text-lg text-white">{nextRace.raceName}</h3>
                    <p className="text-gray-300 flex items-center mt-1">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(nextRace.date).toLocaleDateString(settings.language)}
                    </p>
                    <p className="text-gray-400 flex items-center mt-1">
                      <MapPin className="w-4 h-4 mr-1" />
                      {nextRace.circuit.location.locality}, {nextRace.circuit.location.country}
                    </p>
                    <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/50">
                      Round {nextRace.round}
                    </Badge>
                  </CardContent>
                </Card>
              )}

              {/* Weather */}
              {weather && nextRace && (
                <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                  <CardHeader>
                    <CardTitle className="flex items-center text-green-400">
                      <CloudRain className="w-5 h-5 mr-2" />
                      {t.weather}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <h3 className="font-bold text-white">{nextRace.circuit.location.locality}</h3>
                    <p className="text-2xl font-bold flex items-center text-white">
                      <Thermometer className="w-6 h-6 mr-2" />
                      {weather.current_weather.temperature}°C
                    </p>
                    <p className="text-gray-400 flex items-center mt-2">
                      <Wind className="w-4 h-4 mr-1" />
                      {t.language === "ru" ? "Ветер" : "Wind"}: {weather.current_weather.windspeed} km/h
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Championship Leader */}
              {championshipLeader && (
                <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                  <CardHeader>
                    <CardTitle className="flex items-center text-green-400">
                      <Trophy className="w-5 h-5 mr-2" />
                      {t.championshipLeader}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <h3 className="font-bold text-lg text-white">
                      {championshipLeader?.driver
                        ? `${getFlagEmoji(championshipLeader.driver.nationality)} ${championshipLeader.driver.givenName} ${championshipLeader.driver.familyName}`
                        : "—"}
                    </h3>
                    <p className="text-gray-300">{championshipLeader.constructors[0]?.name}</p>
                    <p className="text-2xl font-bold text-green-400">{championshipLeader.points} pts</p>
                    <p className="text-gray-400">
                      {championshipLeader.wins} {t.wins}
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Last Race Results */}
            {lastRaceData?.race && (
              <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                <CardHeader>
                  <CardTitle className="flex items-center text-green-400">
                    <Trophy className="w-5 h-5 mr-2" />
                    {t.lastRace}: {lastRaceData.race.raceName}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Race Results */}
                    <div>
                      <h4 className="font-semibold mb-3 text-green-400">{t.results}</h4>
                      <div className="space-y-2">
                        {lastRaceData.race.results?.slice(0, 3).map((result: any, index: number) => (
                          <div key={index} className="flex items-center space-x-3">
                            <span className="text-lg font-bold text-green-400">{result.position}</span>
                            <div>
                              <p className="font-medium text-white">
                                {result.driver
                                  ? `${getFlagEmoji(result.driver.nationality)} ${result.driver.givenName} ${result.driver.familyName}`
                                  : "—"}
                              </p>
                              <p className="text-sm text-gray-400">{result.constructor.name}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Qualifying */}
                    {lastRaceData.qualifying?.qualifying && (
                      <div>
                        <h4 className="font-semibold mb-3 text-green-400">{t.qualifying}</h4>
                        <div className="space-y-2">
                          {lastRaceData.qualifying.qualifying.slice(0, 3).map((result: any, index: number) => (
                            <div key={index} className="flex items-center space-x-3">
                              <span className="text-lg font-bold text-green-400">{result.position}</span>
                              <div>
                                <p className="font-medium text-white">
                                  {result.driver
                                    ? `${getFlagEmoji(result.driver.nationality)} ${result.driver.givenName} ${result.driver.familyName}`
                                    : "—"}
                                </p>
                                <p className="text-sm text-gray-400">{result.q3 || result.q2 || result.q1}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Sprint */}
                    {lastRaceData.sprint?.sprint && (
                      <div>
                        <h4 className="font-semibold mb-3 text-green-400">{t.sprint}</h4>
                        <div className="space-y-2">
                          {lastRaceData.sprint.sprint.slice(0, 3).map((result: any, index: number) => (
                            <div key={index} className="flex items-center space-x-3">
                              <span className="text-lg font-bold text-green-400">{result.position}</span>
                              <div>
                                <p className="font-medium text-white">
                                  {result.driver
                                    ? `${getFlagEmoji(result.driver.nationality)} ${result.driver.givenName} ${result.driver.familyName}`
                                    : "—"}
                                </p>
                                <p className="text-sm text-gray-400">{result.points} pts</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Latest News */}
            {news.length > 0 && (
              <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                <CardHeader>
                  <CardTitle className="flex items-center text-green-400">
                    <Zap className="w-5 h-5 mr-2" />
                    {t.latestNews}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {news.slice(0, 3).map((item, index) => (
                      <div key={index} className="border-b border-gray-700 pb-4 last:border-b-0">
                        <h4
                          className="font-semibold hover:text-green-400 cursor-pointer text-white"
                          onClick={() => window.open(item.link, "_blank")}
                        >
                          {item.title}
                        </h4>
                        {item.summary && <p className="text-gray-400 text-sm mt-1">{item.summary}</p>}
                        <p className="text-gray-500 text-xs mt-2 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {new Date(item.published).toLocaleDateString(settings.language)}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Schedule Tab */}
        {activeTab === "schedule" && (
          <div className="space-y-6">
            {/* Если выбрана гонка - показываем детали */}
            {selectedRace ? (
              <div className="space-y-6">
                {/* Кнопка "Назад" */}
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedRace(null)
                    setRaceResults(null)
                    setRaceWeather(null)
                  }}
                  className="bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
                >
                  ← {t.language === "ru" ? "Назад к расписанию" : "Back to Schedule"}
                </Button>

                {/* Если есть результаты - показываем результаты */}
                {raceResults ? (
                  <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                    <CardHeader>
                      <CardTitle className="flex items-center text-green-400">
                        <Trophy className="w-5 h-5 mr-2" />
                        {selectedRace.raceName} {selectedRace.season} - {t.results}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Race Results */}
                        {raceResults.race?.results && (
                          <div>
                            <h4 className="font-semibold mb-3 text-green-400">{t.results}</h4>
                            <div className="space-y-2 max-h-96 overflow-y-auto">
                              {raceResults.race.results.slice(0, 20).map((result: any, index: number) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between p-2 bg-gray-800/30 rounded border border-green-500/20"
                                >
                                  <div className="flex items-center space-x-3 min-w-0 flex-1">
                                    <span className="text-lg font-bold text-green-400 flex-shrink-0">
                                      {result.position}
                                    </span>
                                    <div className="min-w-0 flex-1">
                                      <p className="font-medium text-white truncate">
                                        {result.driver
                                          ? `${getFlagEmoji(result.driver.nationality)} ${result.driver.givenName} ${result.driver.familyName}`
                                          : "—"}
                                      </p>
                                      <p className="text-sm text-gray-400 truncate">{result.constructor?.name}</p>
                                    </div>
                                  </div>
                                  <span className="text-green-400 font-semibold flex-shrink-0">
                                    {result.Time?.time ?? result.points + " pts"}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Qualifying */}
                        {raceResults.qualifying?.qualifying && (
                          <div>
                            <h4 className="font-semibold mb-3 text-green-400">{t.qualifying}</h4>
                            <div className="space-y-2 max-h-96 overflow-y-auto">
                              {raceResults.qualifying.qualifying.slice(0, 20).map((result: any, index: number) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between p-2 bg-gray-800/30 rounded border border-green-500/20"
                                >
                                  <div className="flex items-center space-x-3 min-w-0 flex-1">
                                    <span className="text-lg font-bold text-green-400 flex-shrink-0">
                                      {result.position}
                                    </span>
                                    <div className="min-w-0 flex-1">
                                      <p className="font-medium text-white truncate">
                                        {result.driver
                                          ? `${getFlagEmoji(result.driver.nationality)} ${result.driver.givenName} ${result.driver.familyName}`
                                          : "—"}
                                      </p>
                                      <p className="text-sm text-gray-400 truncate">{result.constructor?.name}</p>
                                    </div>
                                  </div>
                                  <span className="text-gray-300 text-sm flex-shrink-0">
                                    {result.q3 || result.q2 || result.q1 || result.Time?.time || "—"}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Sprint */}
                        {raceResults.sprint?.sprint && (
                          <div>
                            <h4 className="font-semibold mb-3 text-green-400">{t.sprint}</h4>
                            <div className="space-y-2 max-h-96 overflow-y-auto">
                              {raceResults.sprint.sprint.slice(0, 20).map((result: any, index: number) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between p-2 bg-gray-800/30 rounded border border-green-500/20"
                                >
                                  <div className="flex items-center space-x-3 min-w-0 flex-1">
                                    <span className="text-lg font-bold text-green-400 flex-shrink-0">
                                      {result.position}
                                    </span>
                                    <div className="min-w-0 flex-1">
                                      <p className="font-medium text-white truncate">
                                        {result.driver
                                          ? `${getFlagEmoji(result.driver.nationality)} ${result.driver.givenName} ${result.driver.familyName}`
                                          : "—"}
                                      </p>
                                      <p className="text-sm text-gray-400 truncate">{result.constructor?.name}</p>
                                    </div>
                                  </div>
                                  <span className="text-green-400 font-semibold flex-shrink-0">
                                    {result.Time?.time ?? result.points + " pts"}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  /* Если нет результатов - показываем информацию о гонке и погоду */
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Race Information */}
                    <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                      <CardHeader>
                        <CardTitle className="flex items-center text-green-400">
                          <Info className="w-5 h-5 mr-2" />
                          {t.raceInformation}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <h3 className="text-xl font-bold text-white mb-2">{selectedRace.raceName}</h3>
                            <p className="text-gray-300 flex items-center">
                              <MapPin className="w-4 h-4 mr-1" />
                              {selectedRace.circuit.circuitName}
                            </p>
                            <p className="text-gray-400">
                              {selectedRace.circuit.location.locality}, {selectedRace.circuit.location.country}
                            </p>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div className="bg-gray-800/50 p-3 rounded-lg">
                              <p className="text-sm text-gray-400">{t.circuitLength}</p>
                              <p className="text-white font-semibold">
                                {getCircuitInfo(selectedRace.circuit.circuitId).length}
                              </p>
                            </div>
                            <div className="bg-gray-800/50 p-3 rounded-lg">
                              <p className="text-sm text-gray-400">{t.numberOfLaps}</p>
                              <p className="text-white font-semibold">
                                {getCircuitInfo(selectedRace.circuit.circuitId).laps}
                              </p>
                            </div>
                            <div className="bg-gray-800/50 p-3 rounded-lg">
                              <p className="text-sm text-gray-400">{t.raceDistance}</p>
                              <p className="text-white font-semibold">
                                {getCircuitInfo(selectedRace.circuit.circuitId).distance}
                              </p>
                            </div>
                            <div className="bg-gray-800/50 p-3 rounded-lg">
                              <p className="text-sm text-gray-400">{t.drsZones}</p>
                              <p className="text-white font-semibold">
                                {getCircuitInfo(selectedRace.circuit.circuitId).drsZones}
                              </p>
                            </div>
                          </div>

                          <div className="bg-gray-800/50 p-3 rounded-lg">
                            <p className="text-sm text-gray-400">{t.lapRecord}</p>
                            <p className="text-white font-semibold">
                              {getCircuitInfo(selectedRace.circuit.circuitId).lapRecord}
                            </p>
                          </div>

                          <div className="bg-gray-800/50 p-3 rounded-lg">
                            <p className="text-sm text-gray-400">{t.firstGrandPrix}</p>
                            <p className="text-white font-semibold">
                              {getCircuitInfo(selectedRace.circuit.circuitId).firstGP}
                            </p>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4 text-green-400" />
                            <span className="text-white font-semibold">
                              {new Date(selectedRace.date).toLocaleDateString(settings.language, {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </span>
                          </div>
                          {selectedRace.time && (
                            <div className="flex items-center space-x-2">
                              <Clock className="w-4 h-4 text-green-400" />
                              <span className="text-white font-semibold">{selectedRace.time}</span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Weather Information */}
                    {raceWeather && (
                      <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                        <CardHeader>
                          <CardTitle className="flex items-center text-green-400">
                            <CloudRain className="w-5 h-5 mr-2" />
                            {t.weather}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="text-center">
                              <h3 className="text-lg font-bold text-white mb-2">
                                {selectedRace.circuit.location.locality}
                              </h3>
                              <div className="text-4xl font-bold text-white mb-2">
                                {raceWeather.current_weather.temperature}°C
                              </div>
                              <p className="text-gray-400">
                                {t.language === "ru" ? "Текущая погода" : "Current Weather"}
                              </p>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div className="bg-gray-800/50 p-3 rounded-lg text-center">
                                <Wind className="w-6 h-6 mx-auto mb-2 text-green-400" />
                                <p className="text-sm text-gray-400">{t.language === "ru" ? "Ветер" : "Wind"}</p>
                                <p className="text-white font-semibold">{raceWeather.current_weather.windspeed} km/h</p>
                              </div>
                              <div className="bg-gray-800/50 p-3 rounded-lg text-center">
                                <Navigation className="w-6 h-6 mx-auto mb-2 text-green-400" />
                                <p className="text-sm text-gray-400">
                                  {t.language === "ru" ? "Направление" : "Direction"}
                                </p>
                                <p className="text-white font-semibold">{raceWeather.current_weather.winddirection}°</p>
                              </div>
                            </div>

                            <div className="bg-yellow-900/20 border border-yellow-500/30 p-3 rounded-lg">
                              <p className="text-yellow-400 text-sm">
                                {t.language === "ru"
                                  ? "⚠️ Погода может измениться к дню гонки"
                                  : "⚠️ Weather may change by race day"}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}
              </div>
            ) : (
              /* Основное расписание */
              <>
                {/* Таймер до ближайшей гонки */}
                {nextRace && timeToNextRace && (
                  <Card className="bg-gradient-to-r from-green-900/50 to-green-800/50 border-green-500/50 shadow-lg shadow-green-500/20">
                    <CardHeader>
                      <CardTitle className="flex items-center text-green-400">
                        <Clock className="w-5 h-5 mr-2" />
                        {t.language === "ru" ? "До ближайшей гонки" : "Next Race Countdown"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center">
                        <h3 className="text-xl font-bold text-white mb-4">{nextRace.raceName}</h3>
                        <div className="grid grid-cols-4 gap-4 mb-4">
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-2xl font-bold text-green-400">{timeToNextRace.days}</div>
                            <div className="text-sm text-gray-300">{t.language === "ru" ? "дней" : "days"}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-2xl font-bold text-green-400">{timeToNextRace.hours}</div>
                            <div className="text-sm text-gray-300">{t.language === "ru" ? "часов" : "hours"}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-2xl font-bold text-green-400">{timeToNextRace.minutes}</div>
                            <div className="text-sm text-gray-300">{t.language === "ru" ? "минут" : "minutes"}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-2xl font-bold text-green-400">{timeToNextRace.seconds}</div>
                            <div className="text-sm text-gray-300">{t.language === "ru" ? "секунд" : "seconds"}</div>
                          </div>
                        </div>
                        <p className="text-gray-300 flex items-center justify-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {nextRace.circuit.location.locality}, {nextRace.circuit.location.country}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Список всех гонок */}
                <div className="grid gap-4">
                  {currentSeason.map((race) => {
                    const isCompleted = new Date(race.date) < new Date()
                    const isNext = race === nextRace

                    return (
                      <Card
                        key={race.round}
                        className={`shadow-lg transition-all duration-200 ${
                          isCompleted
                            ? "bg-gray-800/30 border-gray-600/30 shadow-gray-600/10"
                            : isNext
                              ? "bg-green-900/30 border-green-500/50 shadow-green-500/20"
                              : "bg-gray-900/50 border-green-500/30 shadow-green-500/10"
                        }`}
                      >
                        <CardContent className="p-4 sm:p-6">
                          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                                <Badge
                                  className={`w-fit ${
                                    isCompleted
                                      ? "bg-gray-600/20 text-gray-400 border-gray-600/50"
                                      : isNext
                                        ? "bg-green-500/30 text-green-300 border-green-500/70"
                                        : "bg-green-500/20 text-green-400 border-green-500/50"
                                  }`}
                                >
                                  Round {race.round}
                                </Badge>
                                {isCompleted && (
                                  <Badge
                                    variant="outline"
                                    className="w-fit bg-gray-700/50 text-gray-300 border-gray-600/50"
                                  >
                                    {t.completed}
                                  </Badge>
                                )}
                                {isNext && (
                                  <Badge className="w-fit bg-green-500/20 text-green-300 border-green-500/50 animate-pulse">
                                    {t.upcoming}
                                  </Badge>
                                )}
                              </div>
                              <h3
                                className={`text-lg sm:text-xl font-bold mb-2 ${
                                  isCompleted ? "text-gray-300" : "text-white"
                                }`}
                              >
                                {race.raceName}
                              </h3>
                              <p
                                className={`flex items-center mb-1 ${isCompleted ? "text-gray-400" : "text-gray-300"}`}
                              >
                                <MapPin className="w-4 h-4 mr-1 flex-shrink-0" />
                                <span className="truncate">{race.circuit.circuitName}</span>
                              </p>
                              <p className={`${isCompleted ? "text-gray-500" : "text-gray-400"}`}>
                                {race.circuit.location.locality}, {race.circuit.location.country}
                              </p>
                            </div>

                            <div className="flex flex-col sm:flex-row lg:flex-col xl:flex-row gap-3 lg:text-right">
                              <div className="flex-shrink-0">
                                <p
                                  className={`text-base sm:text-lg font-semibold flex items-center sm:justify-end lg:justify-start xl:justify-end ${
                                    isCompleted ? "text-gray-300" : "text-white"
                                  }`}
                                >
                                  <Calendar className="w-4 h-4 mr-1" />
                                  {new Date(race.date).toLocaleDateString(settings.language)}
                                </p>
                                {race.time && (
                                  <p className={`text-sm ${isCompleted ? "text-gray-500" : "text-gray-400"}`}>
                                    {race.time}
                                  </p>
                                )}
                              </div>

                              <div className="flex flex-col sm:flex-row gap-2 min-w-0">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => generateCalendarFile(race)}
                                  className={`w-full sm:w-auto ${
                                    isCompleted
                                      ? "bg-gray-800 text-gray-400 border-gray-600/50 hover:bg-gray-700/50"
                                      : "bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
                                  }`}
                                >
                                  <Download className="w-4 h-4 mr-1 flex-shrink-0" />
                                  <span className="truncate">{t.addToCalendar}</span>
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => loadRaceDetails(race)}
                                  className={`w-full sm:w-auto ${
                                    isCompleted
                                      ? "bg-gray-600 hover:bg-gray-500 text-white"
                                      : "bg-green-500 hover:bg-green-600 text-black"
                                  }`}
                                >
                                  <span className="truncate">{isCompleted ? t.results : t.viewDetails}</span>
                                  <ChevronRight className="w-4 h-4 ml-1 flex-shrink-0" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </>
            )}
          </div>
        )}

        {/* Drivers Tab */}
        {activeTab === "drivers" && (
          <div className="space-y-4">
            {selectedDriver && driverStats ? (
              <DriverDetail
                driver={selectedDriver}
                stats={driverStats}
                onBack={() => {
                  setSelectedDriver(null)
                  setDriverStats(null)
                }}
                language={settings.language}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {CURRENT_DRIVERS.map((driver, index) => (
                  <Card key={index} className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/50">#{driver.number}</Badge>
                        <Badge variant="outline" className="bg-gray-900 text-white border-green-500/50">
                          {driver.team}
                        </Badge>
                      </div>
                      <h3 className="text-lg font-bold flex items-center text-white">
                        {getFlagEmoji(driver.nationality)} {driver.name}
                      </h3>
                      <p className="text-gray-300">{driver.nationality}</p>
                      <p className="text-gray-400">
                        {t.age}: {driver.age}
                      </p>
                      <Button
                        className="w-full mt-4 bg-green-500 hover:bg-green-600 text-black"
                        onClick={() => {
                          setSelectedDriver(driver)
                          loadDriverStats(driver.name)
                        }}
                      >
                        {t.viewDetails}
                      </Button>
                      {settings.favoriteDriver === driver.name && <Star className="w-5 h-5 text-green-400 mt-2" />}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Standings Tab */}
        {activeTab === "standings" && (
          <div className="space-y-4">
            <div className="flex items-center space-x-4 mb-6">
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-32 bg-gray-900 border-green-500/50 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-green-500/50">
                  {Array.from({ length: 16 }, (_, i) => 2025 - i).map((year) => (
                    <SelectItem key={year} value={year.toString()} className="text-white">
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex space-x-2">
                <Button
                  variant={championshipType === "drivers" ? "default" : "outline"}
                  onClick={() => {
                    setChampionshipType("drivers")
                    loadChampionshipData(selectedYear, "drivers")
                  }}
                  className={
                    championshipType === "drivers"
                      ? "bg-green-500 hover:bg-green-600 text-black"
                      : "bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
                  }
                >
                  {t.driverStandings}
                </Button>
                <Button
                  variant={championshipType === "constructors" ? "default" : "outline"}
                  onClick={() => {
                    setChampionshipType("constructors")
                    loadChampionshipData(selectedYear, "constructors")
                  }}
                  className={
                    championshipType === "constructors"
                      ? "bg-green-500 hover:bg-green-600 text-black"
                      : "bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
                  }
                >
                  {t.constructorStandings}
                </Button>
              </div>
            </div>

            <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
              <CardHeader>
                <CardTitle className="flex items-center text-green-400">
                  <Trophy className="w-5 h-5 mr-2" />
                  {championshipType === "drivers" ? t.driverStandings : t.constructorStandings} {selectedYear}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin text-green-400" />
                  </div>
                ) : (
                  <div className="space-y-3">
                    {championshipType === "drivers"
                      ? driverStandings.map((standing, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-green-500/20"
                          >
                            <div className="flex items-center space-x-4">
                              <span className="text-2xl font-bold text-green-400">{standing.position}</span>
                              <div>
                                <h4 className="font-semibold flex items-center text-white">
                                  {getFlagEmoji(standing.driver?.nationality)} {standing.driver?.givenName ?? "—"}{" "}
                                  {standing.driver?.familyName ?? ""}
                                </h4>
                                <p className="text-gray-400 text-sm">{standing.constructors[0]?.name}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-xl font-bold text-white">{standing.points}</p>
                              <p className="text-gray-400 text-sm">{standing.wins} wins</p>
                            </div>
                          </div>
                        ))
                      : constructorStandings.map((standing, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-green-500/20"
                          >
                            <div className="flex items-center space-x-4">
                              <span className="text-2xl font-bold text-green-400">{standing.position}</span>
                              <div>
                                <h4 className="font-semibold flex items-center text-white">
                                  {getFlagEmoji(standing.constructor?.nationality)} {standing.constructor?.name ?? "—"}
                                </h4>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-xl font-bold text-white">{standing.points}</p>
                              <p className="text-gray-400 text-sm">{standing.wins} wins</p>
                            </div>
                          </div>
                        ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* News Tab */}
        {activeTab === "news" && (
          <div className="space-y-4">
            {news.map((item, index) => (
              <Card key={index} className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    {item.image && (
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                    )}
                    <div className="flex-1">
                      <h3
                        className="text-xl font-bold mb-2 hover:text-green-400 cursor-pointer text-white"
                        onClick={() => window.open(item.link, "_blank")}
                      >
                        {item.title}
                      </h3>
                      {item.summary && <p className="text-gray-300 mb-3">{item.summary}</p>}
                      <div className="flex items-center justify-between">
                        <p className="text-gray-500 text-sm flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {new Date(item.published).toLocaleDateString(settings.language)}
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(item.link, "_blank")}
                          className="bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          {t.readMore}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* AI Assistant Tab */}
        {activeTab === "ai" && (
          <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
            <CardHeader>
              <CardTitle className="flex items-center text-green-400">
                <MessageSquare className="w-5 h-5 mr-2" />
                {t.aiAssistant}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder={t.askQuestion}
                  value={aiQuestion}
                  onChange={(e) => setAiQuestion(e.target.value)}
                  className="bg-gray-800 border-green-500/50 text-white placeholder-gray-400"
                  onKeyPress={(e) => e.key === "Enter" && handleAiQuestion()}
                />
                <Button
                  onClick={handleAiQuestion}
                  disabled={isAiLoading || !aiQuestion.trim()}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </div>

              {isAiLoading && (
                <div className="flex items-center space-x-2 text-gray-400">
                  <Loader2 className="animate-spin h-4 w-4" />
                  <span>{t.thinking}</span>
                </div>
              )}

              {aiResponse && (
                <div className="bg-gray-800/50 p-4 rounded-lg border border-green-500/20">
                  <p className="text-gray-200 whitespace-pre-wrap">{aiResponse}</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <div className="grid gap-6">
            <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
              <CardHeader>
                <CardTitle className="flex items-center text-green-400">
                  <User className="w-5 h-5 mr-2" />
                  {t.profile}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-white">{t.favoriteDriver}</label>
                  <Select
                    value={settings.favoriteDriver || ""}
                    onValueChange={async (value) => {
                      setSettings((prev) => ({ ...prev, favoriteDriver: value }))
                      await saveUserData(value, settings.favoriteTeam || "")
                    }}
                  >
                    <SelectTrigger className="bg-gray-800 border-green-500/50 text-white">
                      <SelectValue placeholder={t.selectDriver} />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-green-500/50">
                      {CURRENT_DRIVERS.map((driver) => (
                        <SelectItem key={driver.name} value={driver.name} className="text-white">
                          {getFlagEmoji(driver.nationality)} {driver.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-white">{t.favoriteTeam}</label>
                  <Select
                    value={settings.favoriteTeam || ""}
                    onValueChange={async (value) => {
                      setSettings((prev) => ({ ...prev, favoriteTeam: value }))
                      await saveUserData(settings.favoriteDriver || "", value)
                    }}
                  >
                    <SelectTrigger className="bg-gray-800 border-green-500/50 text-white">
                      <SelectValue placeholder={t.selectTeam} />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-green-500/50">
                      {TEAMS.map((team) => (
                        <SelectItem key={team} value={team} className="text-white">
                          {team}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
              <CardHeader>
                <CardTitle className="flex items-center text-green-400">
                  <Settings className="w-5 h-5 mr-2" />
                  {t.preferences}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Bell className="w-4 h-4 text-white" />
                    <span className="text-white">{t.notifications}</span>
                  </div>
                  <Switch
                    checked={settings.notifications}
                    onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, notifications: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-white" />
                    <span className="text-white">{t.language}</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSettings((prev) => ({ ...prev, language: prev.language === "en" ? "ru" : "en" }))}
                    className="bg-gray-900 text-green-400 border-green-500/50 hover:bg-green-500/20"
                  >
                    {settings.language === "en" ? "English" : "Русский"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Technical Information */}
            <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
              <CardHeader>
                <CardTitle className="flex items-center text-green-400">
                  <Wrench className="w-5 h-5 mr-2" />
                  {t.technical}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-800/50 rounded-lg border border-green-500/20">
                    <div className="flex items-center mb-2">
                      <Car className="w-5 h-5 mr-2 text-green-400" />
                      <h4 className="font-semibold text-white">{t.cars}</h4>
                    </div>
                    <p className="text-sm text-gray-300">
                      {t.language === "ru"
                        ? "Монокок из углеродного волокна, минимальный вес 800 кг, аэродинамика с эффектом земли"
                        : "Carbon fiber monocoque, minimum weight 800kg, ground effect aerodynamics"}
                    </p>
                  </div>

                  <div className="p-4 bg-gray-800/50 rounded-lg border border-green-500/20">
                    <div className="flex items-center mb-2">
                      <Wrench className="w-5 h-5 mr-2 text-green-400" />
                      <h4 className="font-semibold text-white">{t.engines}</h4>
                    </div>
                    <p className="text-sm text-gray-300">
                      {t.language === "ru"
                        ? "1.6л V6 турбо-гибрид, около 1000 л.с., до 15,000 об/мин"
                        : "1.6L V6 turbo-hybrid, around 1000hp, up to 15,000 rpm"}
                    </p>
                  </div>

                  <div className="p-4 bg-gray-800/50 rounded-lg border border-green-500/20">
                    <div className="flex items-center mb-2">
                      <BookOpen className="w-5 h-5 mr-2 text-green-400" />
                      <h4 className="font-semibold text-white">{t.regulations}</h4>
                    </div>
                    <p className="text-sm text-gray-300">
                      {t.language === "ru"
                        ? "Бюджетный лимит $135 млн, 100% экологичное топливо, усиленная безопасность"
                        : "Budget cap $135M, 100% sustainable fuel, enhanced safety measures"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
