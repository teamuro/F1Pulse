"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Trophy, Medal, Flag, Calendar, User, MapPin } from "lucide-react"

interface DriverDetailProps {
  driver: any
  stats: any
  onBack: () => void
  language: "en" | "ru"
}

export default function DriverDetail({ driver, stats, onBack, language }: DriverDetailProps) {
  const texts = {
    en: {
      back: "Back to Drivers",
      wins: "Wins",
      podiums: "Podiums",
      nationality: "Nationality",
      team: "Current Team",
      age: "Age",
      birthDate: "Birth Date",
      totalRaces: "Total Races",
      careerStats: "Career Statistics",
      personalInfo: "Personal Information",
    },
    ru: {
      back: "Назад к пилотам",
      wins: "Победы",
      podiums: "Подиумы",
      nationality: "Национальность",
      team: "Текущая команда",
      age: "Возраст",
      birthDate: "Дата рождения",
      totalRaces: "Всего гонок",
      careerStats: "Статистика карьеры",
      personalInfo: "Личная информация",
    },
  }

  const t = texts[language]

  const calculateAge = (birthDate: string) => {
    const today = new Date()
    const birth = new Date(birthDate)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return age
  }

  const getFlagEmoji = (nationality: string): string => {
    const countryMap: { [key: string]: string } = {
      Dutch: "🇳🇱",
      British: "🇬🇧",
      Monegasque: "🇲🇨",
      Australian: "🇦🇺",
      Spanish: "🇪🇸",
      Canadian: "🇨🇦",
      French: "🇫🇷",
      Argentine: "🇦🇷",
      German: "🇩🇪",
      Brazilian: "🇧🇷",
      "New Zealander": "🇳🇿",
      Thai: "🇹🇭",
      Italian: "🇮🇹",
      Japanese: "🇯🇵",
    }
    return countryMap[nationality] || "🏁"
  }

  const getTeamFromDriverName = (driverName: string) => {
    const teamMap: { [key: string]: string } = {
      "Max Verstappen": "Red Bull",
      "Lando Norris": "McLaren",
      "Charles Leclerc": "Ferrari",
      "Oscar Piastri": "McLaren",
      "Lewis Hamilton": "Ferrari",
      "George Russell": "Mercedes",
      "Fernando Alonso": "Aston Martin",
      "Lance Stroll": "Aston Martin",
      "Pierre Gasly": "Alpine",
      "Franco Colapinto": "Alpine",
      "Esteban Ocon": "Haas",
      "Oliver Bearman": "Haas",
      "Gabriel Bortoleto": "Kick Sauber",
      "Nico Hülkenberg": "Kick Sauber",
      "Liam Lawson": "Racing Bulls",
      "Isack Hadjar": "Racing Bulls",
      "Alex Albon": "Williams",
      "Carlos Sainz Jr.": "Williams",
      "Andrea Kimi Antonelli": "Mercedes",
      "Yuki Tsunoda": "Red Bull",
    }
    return teamMap[driverName] || "Unknown"
  }

  return (
    <div className="space-y-6">
      <Button
        onClick={onBack}
        variant="outline"
        className="bg-black text-green-400 border-green-500/50 hover:bg-green-500/20"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        {t.back}
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Driver Photo and Basic Info */}
        <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
          <CardContent className="p-6 text-center">
            <div className="w-32 h-32 mx-auto mb-4 bg-gray-800 rounded-full flex items-center justify-center">
              <User className="w-16 h-16 text-green-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              {getFlagEmoji(stats.driver?.nationality)} {stats.driver?.givenName} {stats.driver?.familyName}
            </h2>
            <p className="text-green-400 text-lg">
              {getTeamFromDriverName(`${stats.driver?.givenName} ${stats.driver?.familyName}`) || driver.team}
            </p>
            <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/50">
              #{stats.driver?.permanentNumber || "N/A"}
            </Badge>
          </CardContent>
        </Card>

        {/* Career Statistics */}
        <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
          <CardHeader>
            <CardTitle className="flex items-center text-green-400">
              <Trophy className="w-5 h-5 mr-2" />
              {t.careerStats}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-green-400" />
                <span className="text-white">{t.wins}</span>
              </div>
              <span className="text-2xl font-bold text-green-400">{stats.wins || 0}</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Medal className="w-5 h-5 text-green-400" />
                <span className="text-white">{t.podiums}</span>
              </div>
              <span className="text-2xl font-bold text-green-400">{stats.podiums || 0}</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Flag className="w-5 h-5 text-green-400" />
                <span className="text-white">{t.totalRaces}</span>
              </div>
              <span className="text-2xl font-bold text-green-400">{stats.totalRaces || 0}</span>
            </div>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card className="bg-gray-900/50 border-green-500/30 shadow-lg shadow-green-500/10">
          <CardHeader>
            <CardTitle className="flex items-center text-green-400">
              <User className="w-5 h-5 mr-2" />
              {t.personalInfo}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-green-400" />
                <span className="text-white">{t.nationality}</span>
              </div>
              <span className="text-white">{stats.driver?.nationality || "—"}</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-green-400" />
                <span className="text-white">{t.age}</span>
              </div>
              <span className="text-white">
                {stats.driver?.dateOfBirth ? calculateAge(stats.driver.dateOfBirth) : "—"}{" "}
                {language === "ru" ? "лет" : "years"}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-green-400" />
                <span className="text-white">{t.birthDate}</span>
              </div>
              <span className="text-white">
                {stats.driver?.dateOfBirth ? new Date(stats.driver.dateOfBirth).toLocaleDateString(language) : "—"}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
