"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Trophy,
  Users,
  Calendar,
  Flag,
  Zap,
  Settings,
  MessageSquare,
  Bell,
  Globe,
  CloudRain,
  Send,
  User,
} from "lucide-react"

interface Driver {
  name: string
  team: string
  nationality: string
  number: number
  age: number
  points?: number
}

interface Race {
  round: number
  name: string
  date: string
  location: string
  circuit: string
  status: "upcoming" | "completed"
}

interface NewsItem {
  title: string
  date: string
  summary: string
  url: string
}

const drivers: Driver[] = [
  { name: "Max Verstappen", team: "Red Bull", nationality: "🇳🇱 Netherlands", number: 1, age: 27, points: 393 },
  { name: "Lando Norris", team: "McLaren", nationality: "🇬🇧 United Kingdom", number: 4, age: 25, points: 331 },
  { name: "Charles Leclerc", team: "Ferrari", nationality: "🇲🇨 Monaco", number: 16, age: 27, points: 307 },
  { name: "Oscar Piastri", team: "McLaren", nationality: "🇦🇺 Australia", number: 81, age: 23, points: 262 },
  { name: "Lewis Hamilton", team: "Ferrari", nationality: "🇬🇧 United Kingdom", number: 44, age: 40, points: 164 },
  { name: "George Russell", team: "Mercedes", nationality: "🇬🇧 United Kingdom", number: 63, age: 27, points: 192 },
  { name: "Fernando Alonso", team: "Aston Martin", nationality: "🇪🇸 Spain", number: 14, age: 43, points: 62 },
  { name: "Lance Stroll", team: "Aston Martin", nationality: "🇨🇦 Canada", number: 18, age: 26, points: 24 },
]

const races: Race[] = [
  {
    round: 1,
    name: "Australian Grand Prix",
    date: "March 14-16, 2025",
    location: "Melbourne",
    circuit: "Albert Park",
    status: "upcoming",
  },
  {
    round: 2,
    name: "Chinese Grand Prix",
    date: "March 21-23, 2025",
    location: "Shanghai",
    circuit: "Shanghai International Circuit",
    status: "upcoming",
  },
  {
    round: 3,
    name: "Japanese Grand Prix",
    date: "April 4-6, 2025",
    location: "Suzuka",
    circuit: "Suzuka Circuit",
    status: "upcoming",
  },
  {
    round: 4,
    name: "Bahrain Grand Prix",
    date: "April 11-13, 2025",
    location: "Sakhir",
    circuit: "Bahrain International Circuit",
    status: "upcoming",
  },
  {
    round: 5,
    name: "Saudi Arabian Grand Prix",
    date: "April 18-20, 2025",
    location: "Jeddah",
    circuit: "Jeddah Corniche Circuit",
    status: "upcoming",
  },
]

const news: NewsItem[] = [
  {
    title: "Hamilton Joins Ferrari: The Move That Shocked F1",
    date: "2025-01-15",
    summary: "Lewis Hamilton's surprise move to Ferrari for 2025 season creates new championship dynamics.",
    url: "#",
  },
  {
    title: "New Technical Regulations for 2025 Season",
    date: "2025-01-10",
    summary: "FIA announces updated technical regulations focusing on sustainability and safety improvements.",
    url: "#",
  },
  {
    title: "McLaren's Championship Ambitions",
    date: "2025-01-08",
    summary: "Team principal discusses McLaren's strategy for maintaining their competitive edge in 2025.",
    url: "#",
  },
]

export default function F1Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [language, setLanguage] = useState<"en" | "ru">("en")
  const [aiQuestion, setAiQuestion] = useState("")
  const [aiResponse, setAiResponse] = useState("")
  const [isAiLoading, setIsAiLoading] = useState(false)
  const [notifications, setNotifications] = useState(true)
  const [favoriteDriver, setFavoriteDriver] = useState("")
  const [favoriteTeam, setFavoriteTeam] = useState("")

  const handleAiQuestion = async () => {
    if (!aiQuestion.trim()) return

    setIsAiLoading(true)
    // Simulate AI response
    setTimeout(() => {
      setAiResponse(
        `Here's information about ${aiQuestion}: Formula 1 is a complex sport with many technical aspects. The current season features exciting competition between teams like Red Bull, McLaren, and Ferrari. Each race weekend includes practice sessions, qualifying, and the main race event.`,
      )
      setIsAiLoading(false)
    }, 2000)
  }

  const texts = {
    en: {
      title: "F1 Pulse",
      subtitle: "Your Ultimate Formula 1 Companion",
      overview: "Overview",
      schedule: "Schedule",
      drivers: "Drivers",
      standings: "Standings",
      news: "News",
      aiAssistant: "AI Assistant",
      settings: "Settings",
      weather: "Weather",
      technical: "Technical",
      nextRace: "Next Race",
      driverStandings: "Driver Standings",
      latestNews: "Latest News",
      askQuestion: "Ask about Formula 1...",
      send: "Send",
      notifications: "Notifications",
      language: "Language",
      favoriteDriver: "Favorite Driver",
      favoriteTeam: "Favorite Team",
      profile: "Profile",
    },
    ru: {
      title: "F1 Pulse",
      subtitle: "Ваш главный помощник по Формуле 1",
      overview: "Обзор",
      schedule: "Расписание",
      drivers: "Пилоты",
      standings: "Турнирная таблица",
      news: "Новости",
      aiAssistant: "AI Помощник",
      settings: "Настройки",
      weather: "Погода",
      technical: "Техника",
      nextRace: "Следующая гонка",
      driverStandings: "Зачет пилотов",
      latestNews: "Последние новости",
      askQuestion: "Спросите о Формуле 1...",
      send: "Отправить",
      notifications: "Уведомления",
      language: "Язык",
      favoriteDriver: "Любимый пилот",
      favoriteTeam: "Любимая команда",
      profile: "Профиль",
    },
  }

  const t = texts[language]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-red-900 text-white">
      {/* Header */}
      <header className="bg-black/80 backdrop-blur-md border-b border-red-500/20 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-lg flex items-center justify-center">
              <Flag className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{t.title}</h1>
              <p className="text-red-400 text-sm">{t.subtitle}</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLanguage(language === "en" ? "ru" : "en")}
            className="bg-black text-white border-red-500/30 hover:bg-red-500/20"
          >
            <Globe className="w-4 h-4 mr-2" />
            {language === "en" ? "RU" : "EN"}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7 bg-gray-800/50 border border-red-500/20">
            <TabsTrigger value="overview" className="data-[state=active]:bg-red-500/20">
              <Trophy className="w-4 h-4 mr-2" />
              {t.overview}
            </TabsTrigger>
            <TabsTrigger value="schedule" className="data-[state=active]:bg-red-500/20">
              <Calendar className="w-4 h-4 mr-2" />
              {t.schedule}
            </TabsTrigger>
            <TabsTrigger value="drivers" className="data-[state=active]:bg-red-500/20">
              <Users className="w-4 h-4 mr-2" />
              {t.drivers}
            </TabsTrigger>
            <TabsTrigger value="standings" className="data-[state=active]:bg-red-500/20">
              <Flag className="w-4 h-4 mr-2" />
              {t.standings}
            </TabsTrigger>
            <TabsTrigger value="news" className="data-[state=active]:bg-red-500/20">
              <Zap className="w-4 h-4 mr-2" />
              {t.news}
            </TabsTrigger>
            <TabsTrigger value="ai" className="data-[state=active]:bg-red-500/20">
              <MessageSquare className="w-4 h-4 mr-2" />
              AI
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-red-500/20">
              <Settings className="w-4 h-4 mr-2" />
              {t.settings}
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Next Race */}
              <Card className="bg-gray-900/50 border-red-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-400">
                    <Flag className="w-5 h-5 mr-2" />
                    {t.nextRace}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <h3 className="font-bold text-lg">{races[0].name}</h3>
                  <p className="text-gray-300">{races[0].date}</p>
                  <p className="text-gray-400">{races[0].location}</p>
                  <Badge className="mt-2 bg-red-500/20 text-red-400">Round {races[0].round}</Badge>
                </CardContent>
              </Card>

              {/* Weather */}
              <Card className="bg-gray-900/50 border-red-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-400">
                    <CloudRain className="w-5 h-5 mr-2" />
                    {t.weather}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <h3 className="font-bold">Melbourne</h3>
                  <p className="text-2xl font-bold">22°C</p>
                  <p className="text-gray-300">Partly Cloudy</p>
                  <p className="text-gray-400">Wind: 15 km/h</p>
                </CardContent>
              </Card>

              {/* Championship Leader */}
              <Card className="bg-gray-900/50 border-red-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-400">
                    <Trophy className="w-5 h-5 mr-2" />
                    Championship Leader
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <h3 className="font-bold text-lg">Max Verstappen</h3>
                  <p className="text-gray-300">Red Bull Racing</p>
                  <p className="text-2xl font-bold text-red-400">393 pts</p>
                </CardContent>
              </Card>
            </div>

            {/* Latest News */}
            <Card className="bg-gray-900/50 border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center text-red-400">
                  <Zap className="w-5 h-5 mr-2" />
                  {t.latestNews}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {news.slice(0, 3).map((item, index) => (
                    <div key={index} className="border-b border-gray-700 pb-4 last:border-b-0">
                      <h4 className="font-semibold hover:text-red-400 cursor-pointer">{item.title}</h4>
                      <p className="text-gray-400 text-sm mt-1">{item.summary}</p>
                      <p className="text-gray-500 text-xs mt-2">{item.date}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule" className="space-y-4">
            <div className="grid gap-4">
              {races.map((race) => (
                <Card key={race.round} className="bg-gray-900/50 border-red-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-3">
                          <Badge className="bg-red-500/20 text-red-400">Round {race.round}</Badge>
                          <h3 className="text-xl font-bold">{race.name}</h3>
                        </div>
                        <p className="text-gray-300 mt-2">{race.circuit}</p>
                        <p className="text-gray-400">{race.location}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-semibold">{race.date}</p>
                        <Badge variant={race.status === "upcoming" ? "default" : "secondary"}>{race.status}</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Drivers Tab */}
          <TabsContent value="drivers" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {drivers.map((driver, index) => (
                <Card key={index} className="bg-gray-900/50 border-red-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Badge className="bg-red-500/20 text-red-400">#{driver.number}</Badge>
                      <Badge variant="outline" className="bg-black text-white">
                        {driver.team}
                      </Badge>
                    </div>
                    <h3 className="text-lg font-bold">{driver.name}</h3>
                    <p className="text-gray-300">{driver.nationality}</p>
                    <p className="text-gray-400">Age: {driver.age}</p>
                    {driver.points && <p className="text-red-400 font-semibold mt-2">{driver.points} points</p>}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Standings Tab */}
          <TabsContent value="standings">
            <Card className="bg-gray-900/50 border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center text-red-400">
                  <Trophy className="w-5 h-5 mr-2" />
                  {t.driverStandings}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {drivers.slice(0, 8).map((driver, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <span className="text-2xl font-bold text-red-400">{index + 1}</span>
                        <div>
                          <h4 className="font-semibold">{driver.name}</h4>
                          <p className="text-gray-400 text-sm">{driver.team}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold">{driver.points}</p>
                        <p className="text-gray-400 text-sm">points</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* News Tab */}
          <TabsContent value="news" className="space-y-4">
            {news.map((item, index) => (
              <Card key={index} className="bg-gray-900/50 border-red-500/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2 hover:text-red-400 cursor-pointer">{item.title}</h3>
                  <p className="text-gray-300 mb-3">{item.summary}</p>
                  <div className="flex items-center justify-between">
                    <p className="text-gray-500 text-sm">{item.date}</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-black text-white border-red-500/30 hover:bg-red-500/20"
                    >
                      Read More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* AI Assistant Tab */}
          <TabsContent value="ai">
            <Card className="bg-gray-900/50 border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center text-red-400">
                  <MessageSquare className="w-5 h-5 mr-2" />
                  {t.aiAssistant}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Input
                    placeholder={t.askQuestion}
                    value={aiQuestion}
                    onChange={(e) => setAiQuestion(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                    onKeyPress={(e) => e.key === "Enter" && handleAiQuestion()}
                  />
                  <Button onClick={handleAiQuestion} disabled={isAiLoading} className="bg-red-500 hover:bg-red-600">
                    <Send className="w-4 h-4" />
                  </Button>
                </div>

                {isAiLoading && (
                  <div className="flex items-center space-x-2 text-gray-400">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-400"></div>
                    <span>Thinking...</span>
                  </div>
                )}

                {aiResponse && (
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <p className="text-gray-200">{aiResponse}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="grid gap-6">
              <Card className="bg-gray-900/50 border-red-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-400">
                    <User className="w-5 h-5 mr-2" />
                    {t.profile}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">{t.favoriteDriver}</label>
                    <select
                      value={favoriteDriver}
                      onChange={(e) => setFavoriteDriver(e.target.value)}
                      className="w-full bg-gray-800 border border-gray-600 rounded-md p-2 text-white"
                    >
                      <option value="">Select a driver</option>
                      {drivers.map((driver) => (
                        <option key={driver.name} value={driver.name}>
                          {driver.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">{t.favoriteTeam}</label>
                    <select
                      value={favoriteTeam}
                      onChange={(e) => setFavoriteTeam(e.target.value)}
                      className="w-full bg-gray-800 border border-gray-600 rounded-md p-2 text-white"
                    >
                      <option value="">Select a team</option>
                      <option value="Red Bull">Red Bull</option>
                      <option value="McLaren">McLaren</option>
                      <option value="Ferrari">Ferrari</option>
                      <option value="Mercedes">Mercedes</option>
                      <option value="Aston Martin">Aston Martin</option>
                    </select>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-red-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-400">
                    <Settings className="w-5 h-5 mr-2" />
                    Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Bell className="w-4 h-4" />
                      <span>{t.notifications}</span>
                    </div>
                    <Button
                      variant={notifications ? "default" : "outline"}
                      size="sm"
                      onClick={() => setNotifications(!notifications)}
                      className={
                        notifications
                          ? "bg-red-500 hover:bg-red-600"
                          : "bg-black text-white border-red-500/30 hover:bg-red-500/20"
                      }
                    >
                      {notifications ? "On" : "Off"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Globe className="w-4 h-4" />
                      <span>{t.language}</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLanguage(language === "en" ? "ru" : "en")}
                      className="bg-black text-white border-red-500/30 hover:bg-red-500/20"
                    >
                      {language === "en" ? "English" : "Русский"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
