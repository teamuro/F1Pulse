export interface Driver {
  driverId: string
  givenName: string
  familyName: string
  nationality: string
  dateOfBirth: string
  permanentNumber?: string
  code?: string
  url?: string
}

export interface Constructor {
  constructorId: string
  name: string
  nationality: string
  url?: string
}

export interface Circuit {
  circuitId: string
  circuitName: string
  location: {
    lat: string
    long: string
    locality: string
    country: string
  }
  url?: string
}

export interface Race {
  season: string
  round: string
  raceName: string
  circuit: Circuit
  date: string
  time?: string
  url?: string
  results?: RaceResult[]
  qualifying?: QualifyingResult[]
  sprint?: SprintResult[]
  firstPractice?: Session
  secondPractice?: Session
  thirdPractice?: Session
}

export interface RaceResult {
  position: string
  points: string
  driver: Driver
  constructor: Constructor
  grid?: string
  laps?: string
  status?: string
  time?: {
    millis?: string
    time?: string
  }
  fastestLap?: {
    rank?: string
    lap?: string
    time?: {
      time: string
    }
    averageSpeed?: {
      speed: string
    }
  }
}

export interface QualifyingResult {
  position: string
  driver: Driver
  constructor: Constructor
  q1?: string
  q2?: string
  q3?: string
}

export interface SprintResult {
  position: string
  points: string
  driver: Driver
  constructor: Constructor
  grid?: string
  laps?: string
  status?: string
  time?: {
    time?: string
  }
}

export interface Session {
  date: string
  time: string
}

export interface DriverStanding {
  position: string
  points: string
  wins: string
  driver: Driver
  constructors: Constructor[]
}

export interface ConstructorStanding {
  position: string
  points: string
  wins: string
  constructor: Constructor
}

export interface WeatherData {
  current_weather: {
    temperature: number
    windspeed: number
    winddirection: number
    weathercode: number
  }
}

export interface NewsItem {
  title: string
  link: string
  published: string
  summary?: string
  image?: string
}

export interface UserSettings {
  language: "ru" | "en"
  favoriteDriver?: string
  favoriteTeam?: string
  notifications: boolean
}
